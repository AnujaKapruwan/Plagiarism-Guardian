RESULTS_PER_PAGE = 20

ACCEPTED_FILE_EXTENSIONS = ".pdf,.txt,.pptx,.doc,.docx"
